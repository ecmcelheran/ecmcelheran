/* Assignment 7 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (60 marks)
    Use java to implement a data structure named LinkedList, and implement several methods of the LinkedList.

 */

class Node {
    int data; // 'data' stores the value of a node.
    Node next; // 'next' refers/points to the next node

    // the construction method of class Node.
    Node(int d) {
        data = d;
        next = null;
    }
}

class Q2_LinkedList {
    Node head;

    // Insert 'new_data' at the beginning of the LinkedList
    // (5 marks)
    public void insertAtBeginning(int new_data) {
        /* place your code here */
        Node n = new Node(new_data);
        //if linked list is empty
        if(head!=null) {
            //point next of the n to the current head
            n.next = head;
        }
        //have head point at n
        head = n;
    }

    // Insert 'new_data' at the end of the LinkedList
    // (5 marks)
    public void insertAtEnd(int new_data) {
        /* place your code here */
        Node n = new Node(new_data);
        if(head==null){
            head=n;
        }
        else {
            Node runner = head;
            //go to the end of the linked list
            while (runner.next != null) {
                runner = runner.next;
            }
            //make next of last node point to new node
            runner.next = n;
        }

        //next of last node is null
        n.next = null;
    }

    // Insert 'new_data' after a node referred to as 'prev_node'
    // (10 marks)
    public void insertAfter(Node prev_node, int new_data) {
        /* place your code here */
        Node n = new Node(new_data);
        Node aft_prev = prev_node.next;

        //node after prev_node is new node
        prev_node.next = n;

        //next node after the new node
        n.next = aft_prev;
    }

    // Delete a node located in 'position' of the Linked List. The first element of the LinkedList has a position=0.
    // (10 marks)
    void deleteNode(int position) {
        /* place your code here */
        Node runner = head;
        Node prev = head;

        if(position==0){
            head = runner.next;
        }
        else{
            //move to position
            for(int i=0; i<(position); i++){
                prev = runner;
                runner = runner.next;
            }

            prev.next = runner.next;

        }
    }

    // Search for a node containing the value of 'key' in the LinkedList.
    // If there is a node in the LinkedList whose value is equal to 'key', then return 'true'.
    // If there is no node in the LinkedList whose value is equal to 'key', then return 'false'.
    // (15 marks)
    boolean search(Node head, int key) {
        /* place your code here */
        Node runner = head;

        while(runner!=null){
            if(runner.data == key){
                return true;
            }
            runner = runner.next;
        }

        return false;
    }

    // Sort the nodes in the LinkedList in ascending orders of their values.
    // Requirement: please use bubble sort.
    // Example: for a LinkedList: head->3->5->1->4->2, the sorted LinkedList should be head->1->2->3->4->5.
    // (15 marks)

    void sortLinkedList(Node head) {
        /* place your code here */
        Node prev = head;
        Node runner = head;
        int n;

        if(head==null){
            return;
        }
        else{
            while(prev!=null){
                runner = prev.next;
                while(runner!=null){
                    //if the previous data is greater than the runner data, swap the data.
                    if(prev.data>runner.data){
                        n = runner.data;
                        runner.data = prev.data;
                        prev.data = n;
                    }
                    runner = runner.next;
                }
                prev = prev.next;
            }
        }
    }//end of sort method

    // Print the linked list
    public void printList() {
        Node tnode = head;
        while (tnode != null) {
            System.out.print(tnode.data + " ");
            tnode = tnode.next;
        }
    }

    public static void main(String[] args) {
        /* TA may test different functions of the LinkedList here */
        /* The following is just an example of how to do the test. */

        Q2_LinkedList llist = new Q2_LinkedList();

        llist.insertAtEnd(1);
        llist.insertAtBeginning(2);
        llist.insertAtBeginning(3);
        llist.insertAtEnd(4);
        llist.insertAfter(llist.head.next, 5);

        System.out.println("Linked list: ");
        llist.printList();

        System.out.println("\nAfter deleting an element: ");
        llist.deleteNode(3);
        llist.printList();

        System.out.println();
        int item_to_find = 3;
        if (llist.search(llist.head, item_to_find))
            System.out.println(item_to_find + " is found");
        else
            System.out.println(item_to_find + " is not found");

        llist.sortLinkedList(llist.head);
        System.out.println("\nSorted List: ");
        llist.printList();
    }
}