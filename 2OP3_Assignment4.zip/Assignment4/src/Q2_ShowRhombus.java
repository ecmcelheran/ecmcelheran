/* Assignment 4 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (20 marks)
    Write a java program to display the number rhombus structure.

 * INPUT: user input integer value: n
 * The input should be fed into a subroutine as parameter.
 *
 * OUTPUT: the rhombus structure corresponding to n. (see the following example)
 * Your subroutine should directly print the result and do not return anything.

*
* Example:
* For n=7, the rhombus structure is:
      1
     212
    32123
   4321234
  543212345
 65432123456
7654321234567
 65432123456
  543212345
   4321234
    32123
     212
      1

* For n=3, the rhombus structure is:
  1
 212
32123
 212
  1

 */

import java.util.Scanner;

public class Q2_ShowRhombus {
    public static void rhombus(int n){
        //counter variable - for number of spaces before printing line
        int s = n-1;

        //use loop to track how many numbers in each row
        for(int i=1; i<=n; i++){ //to middle row
            s-=1;
            for(int c=s; c>=0; c--){//spaces before each row
                System.out.print(" ");
            }
            for(int x=i; x>1; x--){//backward nums
                System.out.print(x);
            }
            for(int a=1; a<=i; a++){ //forward numbers
                System.out.print(a);
            }
            System.out.println();
        }
        s+=1;


        for(int i=(n-1); i>=1; i--){ //to end
            for(int c=s; c>=0; c--){//spaces before each row
                System.out.print(" ");
            }
            for(int x=i; x>1; x--){//backward nums
                System.out.print(x);
            }
            for(int a=1; a<=i; a++){ //forward numbers
                System.out.print(a);
            }
            System.out.println();
            s+=1;
        }
    }

    public static void main(String args[])
    {
        Scanner input = new Scanner(System.in);

        //declare variables
        int n;

        System.out.println("Enter an integer: ");
        if(input.hasNextInt()){
            n = input.nextInt();

            rhombus(n);
        }
    }
}
