/* Assignment 4 (100 marks in total; 5% of the final score of this course)
 *
 * Question 1 (20 marks)
    Write a Java program, use 'subroutine', 'if', 'else if' and 'else' to solve a quadratic equation in the following form:

    a*x^2 + b*x + c = 0

 * INPUT: user input real valued coefficients: a, b, c.
 * These inputs should be fed as parameters into a subroutine that you write.
 *
 * OUTPUT: Output the solutions (i.e., roots) to the quadratic function defined by the coefficients a, b and c.
 * If there is no real roots, output: "The equation has no real roots."
 * The above outputs should be produced as a String variable returned by your subroutine.
 *
 * Note: all values must be displayed using two significant digits after decimal point.

*
* Example:
For a=1, b=5 and c=2, the roots are -0.44 and -4.56
 */

import java.util.Scanner;

public class Q1_SolveQuadraticEquation {
    public static String quadratic(int[] coeff){

        double root1, root2, discrim;
        String roots;

        discrim = coeff[1]*coeff[1]-(4*coeff[0]*coeff[2]);
        if(discrim<0){
            roots = ("There are no real roots");
        }

        else{
            root1 = (-coeff[1] + Math.sqrt(discrim))/(2*coeff[0]);
            root2 = (-coeff[1] - Math.sqrt(discrim))/(2*coeff[0]);

            String sroot1 = String.format("%.2f", root1);
            String sroot2 = String.format("%.2f", root2);

            roots = ("For a=" + coeff[0] + " b=" + coeff[1] + " and c=" + coeff[2] + ", the roots are " + sroot1 + " and " + sroot2);
        }

        return roots;

    }

    public static void main(String[] Strings) {
        Scanner input = new Scanner(System.in);
        int a =0,b=0,c=0;
        int[] coeff = new int[3];
        String[] coeff_name = {"a","b","c"};

        for(int i=0; i<coeff.length; i++){
            System.out.print("Enter coefficient " + coeff_name[i] + ": ");
            if(input.hasNextInt()){
                coeff[i] = input.nextInt();
            }
            else{
                System.out.println("Input must be an integer number. Your roots will not be accurate");
            }
        }

        System.out.println(quadratic(coeff));
    }
}//end of class
