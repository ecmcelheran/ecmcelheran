/* Assignment 3 (100 marks in total; 5% of the final score of this course)
 *
 * Question 4 (20 marks)
    Write a Java program to print integer numbers between 1 to a user input integer n, which are divisible by 3, 5 and by both.

 * INPUT: a user input integer n
 * OUTPUT: all the integer numbers between 1 and n that are either divisible by 3 or by 5 or by both.

* Hint: For n=16, the output should be as follows.
    Divided by 3 -> 3, 6, 9, 12, 15.
    Divided by 5 -> 5, 10, 15.
    Divided by 3 and 5 -> 15.
 */

import java.util.Scanner;

public class Q4_FindNumbers {
    public static void main(String args[]) {
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        int n;
        String div_three = "", div_five = "", both = "";

        //get number from user
        System.out.print("Enter an integer: ");
        //check that input is int
        if(input.hasNextInt()){
            n = input.nextInt();

            for(int i=1; i<=n; i++){
                //divisible by 3
                if (i%3==0){
                    div_three+= (i + " ");
                }
                //divisible by 5
                if (i%5==0){
                    div_five+= (i + " ");
                }
                //both
                if (i%3==0 && i%5==0){
                    both += (i + " ");
                }
            }//end of for loop

            //output results
            System.out.println("\nDivisible by 3 -> " + div_three);
            System.out.println("Divisible by 5 -> " + div_five);
            System.out.println("Divisible by both -> " + both);
        }
        else{
            System.out.println("input must be an integer");
        }
    }

}//end of class