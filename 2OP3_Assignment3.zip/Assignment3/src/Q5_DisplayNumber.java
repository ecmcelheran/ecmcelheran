/* Assignment 3 (100 marks in total; 5% of the final score of this course)
 *
 * Question 5 (20 marks)
    Write a program in Java to display (i.e. print) the pattern like right angle triangle with a number.

 * INPUT: an integer number n
 * OUTPUT: print a right angle triangle corresponding to n

 * Example1: for n=3, the right angle triangle should be:
    1
    12
    123

 * Example2: for n=5, the right angle triangle should be:
    1
    12
    123
    1234
    12345

 */

import java.util.Scanner;

public class Q5_DisplayNumber {
    public static void main(String[] args) {
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        int n;
        String nums = "";

        //get number from user
        System.out.print("Enter an integer number: ");
        if(input.hasNextInt()){
            n = input.nextInt();

            if(n>0){
                for(int i=1; i<=n; i++){
                    nums+=i;
                    System.out.println(nums);

                }//end of for loop
            }
            else{
                System.out.println("The number must be greater than 0");
            }//end of greater than 0 if structure
        }
        else{
            System.out.println("Input must be an integer");
        }//end of int if structure
    }
}//end of class
