/* Assignment 3 (100 marks in total; 5% of the final score of this course)
 *
 * Question 1 (20 marks)
    Write a Java program to find the value of following expression.
    a) (101 + 0) / 3
    b) 3.0e-6 * 10000000.1
    c) true && true
    d) false && true
    e) (false && false) || (true && true)
    f) (false || false) && (true && true)

 * INPUT: n/a
 * OUTPUT: the value of each of the above expressions.

 */


public class Q1_ExpressionSolution {
    public static void main(String[] args) {
        /* Place your code here */
        //a) (101 + 0) / 3
        System.out.printf("The result of (101+0)/3 is: %1.2f\n", (101.0+0) /3);
        //b) 3.0e-6 * 10000000.1
        System.out.printf("The result of 3.0e-6*10000000.1 is: %1.3e\n", 3.0e-6*10000000.1);
        //c) true && true
        System.out.println("true && true gives: " + (true && true));
        //d) false && true
        System.out.println("false && true gives: " + (false && true));
        //e) (false && false) || (true && true)
        System.out.println("(false && false) || (true && true) gives: " + ((false && false) || (true && true)));
        //f) (false || false) && (true && true)
        System.out.println("(false || false) && (true && true) gives: " + ((false || false) && (true && true)));

    }
}
