/* Assignment 3 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (20 marks)
    Write a Java program to convert a decimal number (i.e., int value) to octal number.
    Please DO NOT use any Java provided subroutines or any third party subroutines to do the conversion.
    You should write your own code to convert a decimal number to octal number.

    Decimal number: The decimal numeral system is the standard system for denoting integer and non-integer numbers. It is also called base-ten positional numeral system.
    Octal number: The octal numeral system is the base-8 number system, and uses the digits 0 to 7.


 * INPUT: a user input decimal number x
 * OUTPUT: an octal number y converted from x

* Hint: For a decimal number x=1256, the corresponding octal number is y=2350.
 */

import java.util.Scanner;

public class Q2_Decimal2Octal {
    public static void main(String args[]) {
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        int x, rem, octal=0, i=1;

        //get x from user
        System.out.print("Enter an integer: ");

        //check value is int
        if(input.hasNextInt()){
            x = input.nextInt();

            //convert decimal number x to octal number y
            while(x>0){
                rem = x%8;
                x/=8;
                octal+=(rem*i);
                i*=10;
            }

            System.out.println("The octal number is: " + octal);


        }
        else{
            System.out.println("You must enter an integer!");
        }
    }
}//end of class
