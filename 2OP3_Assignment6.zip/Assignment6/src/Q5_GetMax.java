/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 5 (20 marks)
 *
 * Write a complete static method that finds the largest value in a 2-dimension array of ints.
 * The method should have one parameter, which is a 2d array of type int. The largest number
 * in the array should be returned as the value of the method.
 *
 * INPUT: user input a 2-dimension array of type int
 * OUTPUT: the largest number in input array
 *
 * Note: considering how to take users' input, you can set some rules (give users some hints)
 * to make your code user-friendly.
 * User will follow your instruction to input test example.
 *
 * Example:
 * Input: 4  6  8
 *        5  8  9
 *        2  1  8
 * Output: 9
 *
 */

import java.util.Scanner;

public class Q5_GetMax {
    /* place your code here */
    public static int maxValue(int[][] num_array) {
        int max = 0;
        try {
            max = num_array[0][0];

            //go through array
            for (int i = 1; i < num_array.length; i++) {
                for(int j=0; j<num_array[i].length;j++){
                    //replace value of min if the value in the current index of the array is higher
                    if (num_array[i][j] > max) {
                        max = num_array[i][j];
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("\nCannot find the maximum!");
        }

        return max;
    }

    public static int[][] twoDimArr(){
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        int[] dim = new int[2];
        String raw;
        int[][] num_arr;

        //get dimensions of 2 dim array, row x col
        System.out.print("Enter the dimensions of your array (i.e., 1x2, 2x4, etc): ");
        raw = input.next();
        //split string at x to get rows and columns
        String[] string_arr = raw.split("x");
        if(string_arr.length!=2){
            System.out.println("Invalid dimensions");
            num_arr = new int[0][0];
        }
        else {
            //convert to integer array
            for (int i = 0; i < string_arr.length; i++) {
                dim[i] = Integer.parseInt(string_arr[i]);
            }

            num_arr = new int[dim[0]][dim[1]];

            //assign values to array by row
            for (int i = 0; i < dim[0]; i++) {
                System.out.print("Enter a list of " + dim[1] + " numbers with commas in between (i.e. 1,2,3,4,5) for row " + (i+1) + ": ");
                raw = input.next();
                string_arr = raw.split(",");

                try {
                    for (int j = 0; j < dim[1]; j++) {
                        num_arr[i][j] = Integer.parseInt(string_arr[j]);
                    }
                }catch(Exception e){
                    System.out.println("Invalid input");
                }
            }
        }

        return num_arr;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        //declare variables
        int[][] num_arr = twoDimArr();
        int max;

        //call subroutine to get max value of the array
        max = maxValue(num_arr);

        System.out.println("\nThe max value of the array is " + max);
    }
}
