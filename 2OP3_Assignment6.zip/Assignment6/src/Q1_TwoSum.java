/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 1 (20 marks)
 *
 * Write a subroutine, user input an 1D array of integers and an integer target,
 * return indices of the two numbers such that they add up to target.
 *
 * INPUT: user input array and target
 * OUTPUT: the indices of the two numbers such that they add up to target.
 *
 * The array and target are parameters to the subroutine.
 * User can get hint to input array and target number, respectively.
 *
 * Keep the input format in the example and make your code user-friendly.
 *
 * Example:
 * INPUT: [2,7,11,15], 9
 * OUTPUT: [0,1]
 *
 */

import java.util.Scanner;

public class Q1_TwoSum {
    /* place your subroutine code here */
    public static int[] indices(int[] num_arr, int target){
        int add =0;
        //declare variables
        int[] index = new int[2];
        //go through array to find addition that equals target
        //num 1 in addition
        for(int i=0; i<num_arr.length; i++){
            //num 2 in addition
            for(int j=0; j<num_arr.length; j++){
                //if the 2 numbers add to the target, record the indices
                if((num_arr[i] + num_arr[j])==target){
                    index[0] = j;
                    index[1] = i;
                    add = 1;
                }
            }//end of inner for loop
        }//end of outer for loop
        //if there are not numbers that add to the target
        if(add==0){
            System.out.println("Cannot find two numbers that add correctly!");
            System.out.println("--Indices invalid--");
        }

        return index;
    }

    public static int[] makeArray(){
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        String nums;
        int[] num_arr;

        //get array as user input
        System.out.print("Enter a list of integers with commas in between (i.e. 1,2,3,4,5): ");
        nums = input.next();

        //convert input to array
        String[] string_arr = nums.split(",");

        //set int array length
        num_arr = new int[string_arr.length];

        try {
            //convert to string array to integer array
            for (int i = 0; i < string_arr.length; i++) {
                num_arr[i] = Integer.parseInt(string_arr[i]);
            }
        }
        //catch if user incorrectly input array
        catch(Exception e){
            System.out.println("Cannot use array!\nInput invalid!");
            num_arr = new int [0];
        }
        return num_arr;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        int[] index;
        int target;

        //make array from user input
        //call subroutine to make array
        int[] num_arr = makeArray();

        //get target
        System.out.print("Enter your target number: ");
        //check that target is an integer number
        if(input.hasNextInt()){
            target = input.nextInt();

            //call subroutine
            index = indices(num_arr, target);

            //output result
            System.out.println("The indices that add up to the target are [" + index[0] + "," + index[1] + "]");
        }
        else{
            System.out.println("The target must be an integer");
        }
    }
}
