/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (20 marks)
 *
 * Write a java program, use "subroutine" to finish sorting a 2-dimension array.
 *
 * User input a 2-dimension array of double type, return it in non-decreasing
 * order according to values in the first raw, if there are two or more same
 * element in the first raw, keep the original sequence.
 *
 * INPUT: a user input 2-dimension array.
 * OUTPUT: sorted input array in non-decreasing order according to values in the first raw.
 *
 * Note: considering how to take users' input, you can set some rules (give users some hints)
 * to make your code user-friendly.
 * User will follow your instruction to input test example.
 *
 * Example 1
 * INPUT: if user input array (Order 2*4) is
 *        1.45  0.25  8.95  0.99
 *        2.56  5.67  0.47  2.65
 *
 * OUTPUT: 0.25  0.99  1.45  8.95
 *         5.67  2.65  2.56  0.47
 *
 * Example 2
 * INPUT: if user input array (Order 5*5) is
 *        0.95  0.23  0.95  0.95  0.65
 *        2.56  5.67  0.47  2.65  0.47
 *        1.45  0.25  8.95  0.99  0.67
 *        5.67  2.65  0.25  8.95  0.99
 *        1.23  4.21  0.97  7.64  8.52
 *
 * OUTPUT: 0.23  0.65  0.95  0.95  0.95
 *         5.67  0.47  2.56  0.47  2.65
 *         0.25  0.67  1.45  8.95  0.99
 *         2.65  0.99  5.67  0.25  8.95
 *         4.21  8.52  1.23  0.97  7.64
 *
 */

import java.util.Scanner;

public class Q2_Sort2DArray {
    /* place your subroutine code here */
    public static double[][] sort(double[][]nums){
        //declare variables
        double value, row_val;
        int[] index = new int[nums[0].length];
        int ind_val;

        //fill index array with the indices
        for(int i=0; i<index.length; i++){
            index[i]=i;
        }

        //go through first row and swap numbers to be in ascending order
        for(int i=0; i<nums[0].length; i++) {
            for(int j=(i+1); j<nums[0].length; j++) {
                //track value at current index, and the original index of each number
                value = nums[0][i];
                ind_val = index[i];
                //if numbers are not in increasing order OR if two numbers are equal but their original indices are
                //not in ascending order, swap the numbers
                if(nums[0][i] > nums[0][j] || ((nums[0][i] == nums[0][j]) && (index[i]>index[j]))) {
                    //swap numbers
                    nums[0][i] = nums[0][j];
                    nums[0][j] = value;
                    //swap index numbers to track
                    index[i]=index[j];
                    index[j] = ind_val;
                    //reassign indices of other columns to follow the first row
                    for(int a=1; a<nums.length; a++){
                        row_val=nums[a][i];
                        nums[a][i] = nums[a][j];
                        nums[a][j] = row_val;
                    }
                }
            }
        }
        return nums;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        //create scanner object
        Scanner input = new Scanner(System.in);

        //declare variables
        int[] dim = new int[2];
        String raw;
        double[][] sorted;

        //get dimensions of 2 dim array, row x col
        System.out.print("Enter the dimensions of your array (i.e., 1x2, 2x4, etc): ");
        raw = input.next();

        //split string to create an array
        String[] string_arr = raw.split("x");
        //check that there are the correct number of elements to ensure user entered a 2D array dimension
        if(string_arr.length!=2){
            System.out.println("Invalid dimensions");
        }

        else{
            try {
                //convert to integer array
                for(int i=0; i<string_arr.length;i++){
                    dim[i] = Integer.parseInt(string_arr[i]);
                }

                double[][] num_arr = new double[dim[0]][dim[1]];

                //assign values to array by row
                for(int i=0; i<dim[0]; i++){
                    System.out.print("Enter a list of " + dim[1] + " numbers with commas in between (i.e. 1,2,3,4,5) for row " + (i+1) + ": ");
                    raw = input.next();
                    string_arr = raw.split(",");

                    for(int j=0; j<dim[1]; j++){
                        num_arr[i][j] = Double.parseDouble(string_arr[j]);
                    }
                }

                //call subroutine to produce a sorted array
                sorted = sort(num_arr);


                //output sorted array
                System.out.println("\n--SORTED ARRAY--");
                for(int i=0; i<dim[0]; i++){
                    for(int j=0; j<dim[1]; j++){
                        System.out.print(sorted[i][j] + " ");
                    }
                    System.out.print("\n");
                }

            }catch(Exception e){
                System.out.println("Cannot sort array!");
                sorted = new double[0][0];
            }

        }
    }
}
