/* Assignment 6 (100 marks in total; 5% of the final score of this course)
 *
 * Question 3 (20 marks)
 *
 * Write a Java program, user input a 1-dimension array of integers, firstly
 * sorting it in non-increasing order, and then remove the duplicates in the
 * array (if exists).
 *
 * INPUT: user input a 1-dimension array.
 * OUTPUT: sorted array in non-increasing order, and without any repeating element.
 *
 * Note: You must write sort algorithm by yourself, you are not supposed to
 * use Arrays.sort() to output the result directly.
 *
 * Hint: you can use bubble sorting algorithm or other sorting algorithms.
 *
 * Keep the input format in the example and make your code user-friendly.
 *
 * Example 1:
 * INPUT: [0, 1, 1, 0, 1, 2, 2, 3, 3, 4]
 * OUTPUT: [4, 3, 2, 1, 0]
 *
 * Example 2:
 * INPUT: [7, 0, 4, 2, 9]
 * OUTPUT: [9, 7, 4, 2, 0]
 *
 */

import java.util.Scanner;

public class Q3_RemoveDuplicates {
    /* place your subroutine code here */
    public static int[] sort(int[]nums){
        //declare variables
        int value;

        for(int i=0; i<nums.length; i++) {

            for(int j=i; j<nums.length; j++) {
                value = nums[i];
                if(nums[i] < nums[j]) {
                    //swap numbers
                    nums[i] = nums[j];
                    nums[j] = value;
                }
            }

        }
        return nums;
    }

    public static int[] removeDup(int[] nums){
        //declare variables
        int[] new_arr;
        int counter = 0;

        //increment counter for each duplicate to get length of new array
        for(int i=0; i<(nums.length-1); i++){
            if (nums[i]==nums[i+1]){
                counter++;
            }
        }

        new_arr = new int[nums.length-counter];
        //reset counter to use again to track index of array when assigning values to the new array
        counter=0;
        //go through array and only add number to new array if it is different than the next number
        for(int i=0; i<nums.length; i++){
            if(i!=(nums.length-1)){
                if(nums[i] != nums[i+1]){
                    new_arr[counter] = nums[i];
                    //increment counter to track index to be assigned
                    counter++;
                }
            }
            else{
                //the last element of the array will be the same
                new_arr[counter]=nums[i];
            }
        }
        return new_arr;
    }

    public static int[] makeArray(){
        Scanner input = new Scanner(System.in);

        String nums;
        int[] num_arr;
        try {
            //get array as user input
            System.out.print("Enter a list of integers with commas in between (i.e. 1,2,3,4,5): ");
            nums = input.next();

            //convert input to array
            String[] string_arr = nums.split(",");

            //set int array length
            num_arr = new int[string_arr.length];

            //convert to string array to integer array
            for (int i = 0; i < string_arr.length; i++) {
                num_arr[i] = Integer.parseInt(string_arr[i]);
            }
        }
        catch(Exception e){
            System.out.println(e);
            num_arr = new int [0];
        }

        return num_arr;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        int[] arr, sorted_arr, no_dup_arr;

        //call subroutine to make the array
        arr = makeArray();
        //sort the array
        sorted_arr = sort(arr);
        //call subroutine to create an array without duplicate numbers
        no_dup_arr = removeDup(sorted_arr);

        //output the array without duplicates
        System.out.print("[");
        for(int i=0; i<no_dup_arr.length; i++){
            if(i==(no_dup_arr.length-1)){
                System.out.print(no_dup_arr[i]);
            }
            else {
                System.out.print(no_dup_arr[i] + ", ");
            }
        }
        System.out.print("]");
    }
}
