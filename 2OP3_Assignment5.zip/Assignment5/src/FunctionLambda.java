public interface FunctionLambda {
    double valueAt(double x, double y);
}
