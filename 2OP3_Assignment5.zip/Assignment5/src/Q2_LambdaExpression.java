/* Assignment 5 (100 marks in total; 5% of the final score of this course)
 *
 * Question 2 (20 marks)
 *
 * Use a "subroutine" and a lambda expression to implement function
 * f(x,y) = sqrt(x*x-y*y), both x and y are real numbers.
 * Meanwhile, your code can throw an IllegalException (custom run-time exception,
 * which can be one provided by Java) if the value of (x*x-y*y) is negative.
 *
 * INPUT: the value of x and y (user input)
 * OUTPUT: the value of sqrt(x*x-y*y)
 *
 * Note: output must be displayed using four significant digits after decimal point.
 *
 */

import java.util.Scanner;

public class Q2_LambdaExpression {
    /* place your subroutine code here */
    static FunctionLambda square_root = (x,y)->{
        double value = ((x*x)-(y*y));
        double result;
        try{
            result = Math.sqrt(value);
        }
        catch(Exception e){
            System.out.println("Cannot compute square root!");
            result = Double.NaN;
        }
        return result;
    };

    public static void main(String[] args){
        /* place your code to run your subroutine here */
        Scanner input = new Scanner(System.in);

        //declare variables
        double x=0,y=0;

        //get x and y from user, and check that input is valid
        System.out.print("Enter a number x: ");
        if(input.hasNextDouble()){
            x = input.nextDouble();

            System.out.print("Enter a number y: ");
            if(input.hasNextDouble()){
                y = input.nextDouble();
                System.out.printf("The square root of (x*x - y*y) = %.4f", square_root.valueAt(x,y));
            }
            else{
                System.out.println("Your input must still be a real number\nUnable to compute x*x-y*y");
            }
        }
        else{
            System.out.print("Your input must be a real number\nUnable to compute x*x-y*y");
        }
    }
}
