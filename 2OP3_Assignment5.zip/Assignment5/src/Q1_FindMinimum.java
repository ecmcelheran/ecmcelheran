/* Assignment 5 (100 marks in total; 5% of the final score of this course)
 *
 * Question 1 (20 marks)
 *
 * Write a Java program, use 'subroutine' to finds the minimum value of
 * the first N elements of an array of type int.
 * Meanwhile, your code can throw an IllegalException (custom run-time
 * exception, which can be one provided by Java) if N is not in the range
 * of the length of input array.
 *
 * Input: user input array and number N.
 * Output: the minimum value of the first N elements of the array.
 *
 * Note: The array and N are parameters to the subroutine.
 * Users will input an array with no specific length.
 *
 */

import java.util.Scanner;

public class Q1_FindMinimum {
    /* place your subroutine code here */
    public static int minValue(int[] num_array, int n) {
        int min = 0;
        try {
            min = num_array[0];

            //go through array
            for (int i = 1; i < n; i++) {
                //replace value of min if the value in the current index of the array is lower
                if (num_array[i] < min) {
                    min = num_array[i];
                }
            }
        }
        catch(Exception e){
            System.out.println("ERROR: " + e);
            System.out.println("Cannot find the minimum!");
        }

        return min;
    }

    public static void main(String[] args) {
        /* place your code to run your subroutine here */
        int n;
        String nums;
        //create scanner
        Scanner input = new Scanner(System.in);

        //get user to input an array
        System.out.println("Enter a list of integers with commas in between (i.e. 1,2,3,4,5): ");
        nums = input.next();

        String[] string_arr = nums.split(",");

        int[] num_arr = new int[string_arr.length];
        for(int i=0; i<string_arr.length;i++){
            num_arr[i] = Integer.parseInt(string_arr[i]);
        }

        //get N
        System.out.print("Find the input of the first __ elements: ");
        if(input.hasNextInt()){
            n=input.nextInt();
            System.out.println("\nThe minimum value is: " + minValue(num_arr, n));
        }


    }
}


