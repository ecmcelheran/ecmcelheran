/* Assignment 5 (100 marks in total; 5% of the final score of this course)
 *
 * Question 5 (20 marks)
 *
 * Write a java program to convert Roman numbers to integer.
 * Roman numerals are represented by seven different symbols:
 * I, V, X, L, C, D and M
 *
 * Symbol   Value
 *   I        1
 *   V        5
 *   X        10
 *   L        50
 *   C        100
 *   D        500
 *   M        1000
 *
 * For example, 2 is written as II in Roman numeral, just two one's added together.
 * 12 is written as XII, which is simply X + II.
 * The number 27 is written as XXVII, which is XX + V + II.
 *
 * Roman numerals are usually written largest to smallest from left to right.
 * However, the numeral for four is not IIII. Instead, the number four is written
 * as IV. Because the one is before the five we subtract it making four.
 * The same principle applies to the number nine, which is written as IX.
 * There are six instances where subtraction is used:
 *  I can be placed before V (5) and X (10) to make 4 and 9.
 *  X can be placed before L (50) and C (100) to make 40 and 90.
 *  C can be placed before D (500) and M (1000) to make 400 and 900.
 *
 * Input: Roman number (user input, string type)
 * Output: print out corresponding integer
 *
 * Example: if the user enters 'LVIII', the program should output 'LVIII -> 58'
 *
 */

import java.util.Scanner;
public class Q5_Roman2Integer {

    //return int value based on roman numeral
    public static int value(char a){
        switch(a){
            case 'I':
                return 1;
            case 'V':
                return 5;
            case 'X':
                return 10;
            case 'L':
                return 50;
            case 'C':
                return 100;
            case 'D':
                return 500;
            case 'M':
                return 1000;
            default:
                return 0;

        }
    }
    /* place your subroutine code here */
    public static int roman_to_int(String numeral){
        int total = 0;

        //go through roman numeral
        for(int i=0; i<numeral.length(); i++){
            //get int value of the roman numeral
            int num = value(numeral.charAt(i));

            //only compare number to the next if there is room in the length of the roman numeral
            if (i+1<numeral.length()){
                //add the number if it is bigger than the next number
                if(num>=value(numeral.charAt(i+1))){
                    total+=num;
                }
                //subtract if the number is smaller than the next number
                else if(num<value(numeral.charAt(i+1))){
                    total-=num;
                }
            }

            //need to add the last digit
            else{
                total+=num;
            }
        }

        return total;
    }

    public static void main(String[] args){
        /* place your code to run your subroutine here */
        Scanner input = new Scanner(System.in);

        //declare variable
        String numeral;

        //get numeral from user
        System.out.print("Enter a Roman Numeral: ");
        numeral = input.next();
        //put numeral to all uppercase to make sure comparison of letters is valid
        numeral = numeral.toUpperCase();

        //call the subroutine and output solution to the user
        System.out.println("The roman numeral as an integer is " + roman_to_int(numeral));
    }
}
